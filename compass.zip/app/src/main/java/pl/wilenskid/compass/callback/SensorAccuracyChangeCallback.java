package pl.wilenskid.compass.callback;

public interface SensorAccuracyChangeCallback {
    void apply(int sensorAccuracy);
}
